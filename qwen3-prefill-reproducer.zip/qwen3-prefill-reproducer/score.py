"""Score the Qwen3 Talker stress check: path coverage, text-step state and ASR WER per arm.

Usage: python score.py RUN_ROOT
Each arm directory holds summary.json, NN.txt/NN.wav and hook/*.jsonl. WER is reported per arm
and split by whether the request went through a preemption replay in the Talker, and requests that
were not replayed are split again by whether their Talker prefill was chunked.
--decode-row selects which row the async V1 consumer of the scored tree reads when counting cached
rows that were never read: "counter" (upstream main up to 1c0bde507: meta.num_processed_tokens) or
"position" (the chunked-prefill fix: _omni_num_computed_tokens - _omni_prompt_len).
"""

import argparse
import glob
import json
import os
import re
import statistics as S
from collections import defaultdict


def norm(text):
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s']", " ", text.lower())).strip()


def load_calls(arm_dir):
    calls = []
    for path in sorted(glob.glob(os.path.join(arm_dir, "hook", "*.jsonl"))):
        with open(path, encoding="utf-8") as f:
            calls.extend(json.loads(line) for line in f if line.strip())
    return calls


def second_word_deleted(ref, hyp):
    """True when the alignment deletes the reference's second word (the chunked-prefill symptom)."""
    import jiwer

    if len(ref.split()) < 2 or not hyp:
        return None
    chunks = jiwer.process_words(ref, hyp).alignments[0]
    return any(c.type == "delete" and c.ref_start_idx <= 1 < c.ref_end_idx for c in chunks)


def per_request(calls, decode_row="counter"):
    """Span shapes and text-step state per request, in call order (one Talker process)."""
    reqs = defaultdict(lambda: defaultdict(int))
    state = {}
    for r in calls:
        rid = r["request_id"]
        c = reqs[rid]
        st = state.setdefault(
            rid, {"decoded": False, "last_idx": None, "last_trailing": None, "tail0": None, "cached": 0, "reads": set()}
        )
        n, p, s = r["num_computed"], r["prompt_len"], r["span_len"]
        b, a = r["before"], r["after"]
        if r["is_prefill"]:
            c["prefill_calls"] += 1
            if n > 0:
                c["prefill_nonzero_offset"] += 1
            if n + s > p:
                c["prefill_crossing_prompt_boundary"] += 1
            if n == 0 and st["decoded"]:
                c["replay_restart_from_zero"] += 1
            if r["out_rows"] != s:
                c["prefill_rows_short_of_span"] += 1
            if st["tail0"] is None and a["trailing_rows"] is not None:
                st["tail0"] = a["trailing_rows"]
        else:
            c["decode_calls"] += 1
            if s > 1:
                c["decode_multi_position"] += 1
            # Row the async V1 consumer reads. counter: meta.num_processed_tokens once decode
            # started, else prefill_consumed_text_tokens (1). position: frames before this one.
            if decode_row == "position" and not b["resumable"]:
                idx = n - p
            else:
                idx = b["num_processed"] if b["decode_flag"] else 1
            if r["async_chunk"]:
                if st["last_idx"] is not None and idx != st["last_idx"] + st["last_span"]:
                    c["async_text_index_jump"] += 1
                    c.setdefault("async_text_index_deltas", []).append(idx - st["last_idx"])
                # The V1 consumer reads cached_decode[idx] only when idx is inside the cache;
                # otherwise it uses this step's incoming row and the cache is left untouched.
                if b["cached_decode_rows"] and idx < b["cached_decode_rows"]:
                    st["reads"].add(idx)
                st["last_idx"], st["last_span"] = idx, s
            if a["eos_emitted_set"]:
                c["text_eos_step"] = c["decode_calls"]
                if c["replay_restart_from_zero"]:
                    c["text_eos_after_replay"] += 1
            st["decoded"] = True
        if r["async_chunk"]:
            rows_now = a["cached_decode_rows"] if a["cached_decode_rows"] is not None else b["cached_decode_rows"]
            if rows_now is not None:
                st["cached"] = max(st["cached"], rows_now)
            c["async_cached_rows"] = st["cached"]
            c["async_cached_rows_never_read"] = st["cached"] - len(st["reads"])
        # Non-async queue: any growth after decode began means the queue was rewound.
        if not r["async_chunk"] and a["trailing_rows"] is not None:
            if st["decoded"] and st["last_trailing"] is not None and a["trailing_rows"] > st["last_trailing"]:
                c["sync_text_queue_rewound"] += 1
            st["last_trailing"] = a["trailing_rows"]
    return {rid: dict(c) for rid, c in reqs.items()}


def coverage(reqs):
    total = defaultdict(int)
    for c in reqs.values():
        for k, v in c.items():
            if k in ("text_eos_step", "async_text_index_deltas", "async_cached_rows"):
                continue
            total[k] += v
    total["requests_replayed"] = sum(1 for c in reqs.values() if c.get("replay_restart_from_zero"))
    total["requests_with_nonzero_offset_prefill"] = sum(1 for c in reqs.values() if c.get("prefill_nonzero_offset"))
    return dict(total)


def mean_or_none(values):
    return round(S.mean(values), 4) if values else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run_root")
    ap.add_argument("--decode-row", choices=("counter", "position"), default="counter")
    ap.add_argument("--asr-cache", help="Whisper cache directory (defaults to Whisper's standard cache)")
    a = ap.parse_args()

    import jiwer
    import torch
    import whisper

    torch.set_num_threads(8)
    asr = whisper.load_model("base", device="cpu", download_root=a.asr_cache)
    arms = sorted(d for d in os.listdir(a.run_root) if os.path.isfile(os.path.join(a.run_root, d, "summary.json")))
    report = {
        "run_root": a.run_root,
        "asr": "openai-whisper base, cpu, language=en, temperature=0",
        "decode_row": a.decode_row,
        "arms": {},
    }
    for arm in arms:
        arm_dir = os.path.join(a.run_root, arm)
        with open(os.path.join(arm_dir, "summary.json"), encoding="utf-8") as source:
            summary = json.load(source)
        reqs = per_request(load_calls(arm_dir), a.decode_row)
        rows = {}
        for r in summary["requests"]:
            i = str(r["index"])
            wav = os.path.join(arm_dir, f"{r['index']:02d}.wav")
            # temperature=0 disables the sampled fallback, so garbled clips score the same on every pass.
            hyp = asr.transcribe(wav, language="en", fp16=False, temperature=0.0)["text"]
            ref, hyp_n = norm(r.get("text", "")), norm(hyp)
            n = len(hyp_n.split())
            # Prefix WER scores what was spoken against the same-length reference prefix,
            # so an early stop does not count as deletions.
            prefix_ref = " ".join(ref.split()[: max(n, 1)])
            c = reqs[r["request_id"]]
            rows[i] = {
                "request_id": r["request_id"],
                "wer": round(jiwer.wer(ref, hyp_n), 4) if ref else None,
                "prefix_wer": round(jiwer.wer(prefix_ref, hyp_n), 4) if ref and n else None,
                "audio_seconds": r.get("audio_seconds"),
                "ref_words": len(ref.split()),
                "asr_words": n,
                "replayed": bool(c.get("replay_restart_from_zero")),
                "chunked_prefill": bool(c.get("prefill_nonzero_offset")),
                "second_word_deleted": second_word_deleted(ref, hyp_n) if ref else None,
                "path": c,
                "text": r.get("text", ""),
                "asr": hyp.strip(),
            }
        wers = [w["wer"] for w in rows.values() if w["wer"] is not None]
        rep = [w["wer"] for w in rows.values() if w["wer"] is not None and w["replayed"]]
        clean = [w["wer"] for w in rows.values() if w["wer"] is not None and not w["replayed"]]
        groups = {}
        for name, keep in (
            ("chunked_not_replayed", lambda w: w["chunked_prefill"] and not w["replayed"]),
            ("unchunked_not_replayed", lambda w: not w["chunked_prefill"] and not w["replayed"]),
            ("replayed", lambda w: w["replayed"]),
        ):
            members = [w for w in rows.values() if keep(w) and w["wer"] is not None]
            groups[name] = {
                "n": len(members),
                "wer_mean": mean_or_none([w["wer"] for w in members]),
                "second_word_deleted": sum(bool(w["second_word_deleted"]) for w in members),
            }
        report["arms"][arm] = {
            "requests": len(summary["requests"]),
            "wall_seconds": summary["wall_seconds"],
            "audio_seconds_total": round(sum(r.get("audio_seconds", 0) for r in summary["requests"]), 2),
            "wer_mean": mean_or_none(wers),
            "wer_median": round(S.median(wers), 4) if wers else None,
            "wer_over_0.5": sum(v > 0.5 for v in wers),
            "prefix_wer_mean": mean_or_none([w["prefix_wer"] for w in rows.values() if w["prefix_wer"] is not None]),
            "replayed_n": len(rep),
            "replayed_wer_mean": mean_or_none(rep),
            "not_replayed_n": len(clean),
            "not_replayed_wer_mean": mean_or_none(clean),
            "groups": groups,
            "coverage": coverage(reqs),
            "per_request": rows,
        }
    out = os.path.join(a.run_root, "score.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    keys = (
        "wer_mean",
        "wer_median",
        "wer_over_0.5",
        "prefix_wer_mean",
        "audio_seconds_total",
        "replayed_n",
        "replayed_wer_mean",
        "not_replayed_n",
        "not_replayed_wer_mean",
    )
    for arm, r in report["arms"].items():
        print(arm, {k: r[k] for k in keys})
        print("   groups", r["groups"])
        print("   coverage", r["coverage"])


if __name__ == "__main__":
    main()
