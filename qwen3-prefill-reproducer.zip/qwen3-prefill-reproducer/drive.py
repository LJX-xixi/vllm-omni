"""Generate text and audio for a fixed prompt set with Qwen3-Omni (Talker stress check).

Prompt format and per-stage sampling follow vllm_omni/deploy/qwen3_omni_moe.yaml and
examples/offline_inference/qwen3_omni/end2end.py: greedy Thinker, Talker sampled at
temperature 0.9 / top_k 50 with seed 42, greedy Code2Wav.
Writes <out>/<index>.txt, <out>/<index>.wav and <out>/summary.json.
"""

import argparse
import json
import os
import time

import soundfile as sf
import torch
from vllm.sampling_params import SamplingParams
from vllm_omni.entrypoints.omni import Omni

SYSTEM = (
    "You are Qwen, a virtual human developed by the Qwen Team, Alibaba "
    "Group, capable of perceiving auditory and visual inputs, as well as "
    "generating text and speech."
)
TALKER_CODEC_EOS = 2150


def build_prompt(question: str) -> dict:
    return {
        "prompt": (
            f"<|im_start|>system\n{SYSTEM}<|im_end|>\n<|im_start|>user\n{question}<|im_end|>\n<|im_start|>assistant\n"
        )
    }


def audio_array(audio) -> "torch.Tensor":
    if isinstance(audio, list):
        audio = torch.cat([(t if isinstance(t, torch.Tensor) else torch.tensor(t)).flatten() for t in audio])
    return audio.detach().float().cpu().reshape(-1)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--deploy-config", required=True)
    ap.add_argument("--prompts", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--thinker-max-tokens", type=int, default=120)
    ap.add_argument("--talker-max-tokens", type=int, default=640)
    a = ap.parse_args()

    with open(a.prompts, encoding="utf-8") as f:
        questions = [ln.strip() for ln in f if ln.strip()]
    os.makedirs(a.out, exist_ok=True)

    omni = Omni(model=a.model, deploy_config=a.deploy_config, stage_init_timeout=900, init_timeout=1800)
    thinker = SamplingParams(temperature=0.0, max_tokens=a.thinker_max_tokens, seed=42)
    talker = SamplingParams(
        temperature=0.9,
        top_k=50,
        max_tokens=a.talker_max_tokens,
        seed=42,
        detokenize=False,
        repetition_penalty=1.05,
        stop_token_ids=[TALKER_CODEC_EOS],
    )
    code2wav = SamplingParams(
        temperature=0.0, top_p=1.0, top_k=-1, max_tokens=65536, seed=42, detokenize=True, repetition_penalty=1.1
    )

    prompts = [build_prompt(q) for q in questions]
    records: dict[int, dict] = {i: {"index": i, "question": q} for i, q in enumerate(questions)}
    prompt_indices = {id(prompt): i for i, prompt in enumerate(prompts)}
    request_indices: dict[str, int] = {}
    add_request = omni.engine.add_request

    def record_submission(*, request_id, prompt, **kwargs):
        index = prompt_indices[id(prompt)]
        request_indices[request_id] = index
        records[index]["request_id"] = request_id
        return add_request(request_id=request_id, prompt=prompt, **kwargs)

    omni.engine.add_request = record_submission
    start = time.time()
    try:
        for out in omni.generate(prompts, [thinker, talker, code2wav]):
            rid = str(out.request_id)
            i = request_indices[rid]
            rec = records[i]
            rec.setdefault("finish_reasons", {})[out.final_output_type] = getattr(out.outputs[0], "finish_reason", None)
            if out.final_output_type == "text":
                rec["text"] = out.outputs[0].text.strip()
                rec["thinker_tokens"] = len(out.outputs[0].token_ids)
                with open(os.path.join(a.out, f"{i:02d}.txt"), "w", encoding="utf-8") as f:
                    f.write(rec["text"] + "\n")
            elif out.final_output_type == "audio":
                if rec.get("audio_outputs", 0):
                    raise RuntimeError(f"Unexpected repeated final audio for {rid}")
                audio = audio_array(out.outputs[0].multimodal_output["audio"]).numpy()
                sf.write(os.path.join(a.out, f"{i:02d}.wav"), audio, samplerate=24000)
                rec["audio_seconds"] = round(len(audio) / 24000, 3)
                rec["audio_outputs"] = 1
    finally:
        omni.close()

    summary = {
        "wall_seconds": round(time.time() - start, 2),
        "deploy_config": a.deploy_config,
        "thinker_max_tokens": a.thinker_max_tokens,
        "talker_max_tokens": a.talker_max_tokens,
        "requests": [records[i] for i in sorted(records)],
    }
    with open(os.path.join(a.out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    missing = [r["index"] for r in summary["requests"] if "audio_seconds" not in r or "text" not in r]
    print(json.dumps({"requests": len(summary["requests"]), "missing": missing, "wall": summary["wall_seconds"]}))
    if missing:
        raise SystemExit(f"missing outputs for {missing}")


if __name__ == "__main__":
    main()
