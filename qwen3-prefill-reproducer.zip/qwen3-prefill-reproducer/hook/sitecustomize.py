"""Record Qwen3-Omni talker_preprocess span metadata for the Talker stress check.

Loaded through PYTHONPATH in every engine process. After the model module is
imported, ``talker_preprocess`` is wrapped (before the model instance binds it
via ``set_custom_preprocess``) to append one JSON line per call: request id,
runner phase metadata, span length, the span's input token ids, and the
request state the Talker reads to pick its text step (``meta`` counters, the
non-async ``trailing_text`` queue and the async ``cached_decode`` queue).
Inputs and results are not modified. Use an isolated Python environment;
this observer does not load host-specific sitecustomize files.
"""

import importlib.abc
import importlib.util
import json
import os
import sys

_TARGET = "vllm_omni.model_executor.models.qwen3_omni.qwen3_omni"
_OUT_DIR = os.environ.get("Q3TS_HOOK_DIR")


def _rows(value):
    shape = getattr(value, "shape", None)
    if shape is None:
        return None
    return int(shape[0]) if len(shape) > 0 else 0


def _wrap(module):
    cls = module.Qwen3OmniMoeForConditionalGeneration
    original = cls.talker_preprocess
    path = os.path.join(_OUT_DIR, f"talker_preprocess.{os.getpid()}.jsonl")

    def talker_preprocess(self, input_ids, input_embeds, **info):
        meta = info.get("meta") or {}
        hs = info.get("hidden_states") or {}
        embed = info.get("embed") or {}
        before = {
            "num_processed": meta.get("num_processed_tokens"),
            "decode_flag": bool(meta.get("decode_flag", False)),
            "eos_emitted": bool(meta.get("eos_emitted", False)),
            "resumable": bool(meta.get("resumable", False)),
            "trailing_rows": _rows(hs.get("trailing_text")),
            "trailing_ndim": getattr(hs.get("trailing_text"), "ndim", None),
            "cached_decode_rows": _rows(embed.get("cached_decode")),
            "decode_rows": _rows(embed.get("decode")),
        }
        record = {
            "request_id": str(info.get("request_id")),
            "is_prefill": info.get("_omni_is_prefill"),
            "num_computed": info.get("_omni_num_computed_tokens"),
            "prompt_len": info.get("_omni_prompt_len"),
            "span_len": int(input_ids.shape[0]),
            "input_ids": input_ids.reshape(-1).tolist(),
            "async_chunk": bool(getattr(self.vllm_config.model_config, "async_chunk", False)),
            "before": before,
        }
        out = original(self, input_ids, input_embeds, **info)
        upd = out[2] if isinstance(out[2], dict) else {}
        upd_meta = upd.get("meta") or {}
        upd_hs = upd.get("hidden_states") or {}
        upd_embed = upd.get("embed") or {}
        record["out_rows"] = int(out[1].shape[0])
        record["after"] = {
            "num_processed": upd_meta.get("num_processed_tokens"),
            "decode_flag_set": upd_meta.get("decode_flag"),
            "eos_emitted_set": upd_meta.get("eos_emitted"),
            "trailing_rows": _rows(upd_hs.get("trailing_text")),
            "cached_decode_rows": _rows(upd_embed.get("cached_decode")),
            "has_mtp_inputs": "mtp_inputs" in upd,
        }
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
        return out

    cls.talker_preprocess = talker_preprocess


class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name != _TARGET:
            return None
        sys.meta_path.remove(self)
        try:
            spec = importlib.util.find_spec(name)
        finally:
            sys.meta_path.insert(0, self)
        if spec is None:
            return None
        loader = spec.loader
        exec_module = loader.exec_module

        def exec_and_wrap(module):
            exec_module(module)
            _wrap(module)

        loader.exec_module = exec_and_wrap
        return spec


if _OUT_DIR:
    os.makedirs(_OUT_DIR, exist_ok=True)
    sys.meta_path.insert(0, _Finder())
